import React from 'react'

export default function Options({ questions,  dispatch, answer }) {
    return (
        <div className="options">
            {questions.options.map( (option, index) =>
             <button className={`btn btn-option`} onClick={()=> dispatch({type: "newAnswer", payload: index})}  key={option}>{option}</button>)}
        </div>
    )
}
